# BakımNet Veritabanı İlişkileri

```mermaid
erDiagram
    USERS ||--o{ WORK_ORDERS : technician
    USERS ||--o{ PROBLEM_REPORTS : reports
    USERS ||--o{ WORK_ORDER_HISTORY : changes
    EQUIPMENT ||--o{ WORK_ORDERS : contains
    EQUIPMENT ||--o{ PROBLEM_REPORTS : concerns
    WORK_ORDERS ||--o{ PART_USAGES : consumes
    SPARE_PARTS ||--o{ PART_USAGES : used_in
    WORK_ORDERS ||--o{ WORK_ORDER_HISTORY : records
    USERS ||--o{ NOTIFICATIONS : receives

    USERS {
        int id PK
        string username UK
        string password_hash
        string role
        boolean is_active
    }
    EQUIPMENT {
        int id PK
        string code
        string name
        string location
    }
    WORK_ORDERS {
        int id PK
        int equipment_id FK
        int technician_id FK
        string status
        string priority
        text description
        text work_done
        datetime completed_at
    }
    PROBLEM_REPORTS {
        int id PK
        int equipment_id FK
        int reported_by FK
        string status
        string priority
        string photo_url
    }
    SPARE_PARTS {
        int id PK
        string code UK
        string name
        int stock_quantity
        int critical_level
    }
    PART_USAGES {
        int id PK
        int work_order_id FK
        int spare_part_id FK
        int quantity
    }
    WORK_ORDER_HISTORY {
        int id PK
        int work_order_id FK
        int changed_by FK
        string old_status
        string new_status
        datetime changed_at
    }
    NOTIFICATIONS {
        int id PK
        int user_id FK
        string notification_type
        string message
        boolean is_read
        datetime created_at
    }
```
