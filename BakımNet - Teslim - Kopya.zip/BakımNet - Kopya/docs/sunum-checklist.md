# Sunum Öncesi Kontrol Listesi

- [ ] `docker compose up --build -d` ile servisleri başlat
- [ ] `http://127.0.0.1:5500` adresinden frontend'i aç
- [ ] Yönetici girişi ve dashboard'u göster
- [ ] Ekipman oluşturma ve konum güncelleme akışını göster
- [ ] İş emri oluşturma, teknisyen atama ve durum filtrelerini göster
- [ ] Teknisyen girişi ile işi başlatma ve tamamlama akışını göster
- [ ] Personel girişi ile sorun bildirimi oluşturmayı göster
- [ ] Yönetici tarafından sorun bildirimini iş emrine dönüştürmeyi göster
- [ ] Stok ve parça ekranında kritik stok seviyesini göster
- [ ] Teknisyen ekranında parça kullanımını ve stoktan düşmeyi göster
- [ ] İş emri durum geçmişini göster
- [ ] Personel sorun bildiriminde geçerli bir fotoğraf yüklemeyi göster
- [ ] Swagger ve `/health` kontrolünü göster
- [ ] Sunumdan önce `python -m pytest` çalıştır
